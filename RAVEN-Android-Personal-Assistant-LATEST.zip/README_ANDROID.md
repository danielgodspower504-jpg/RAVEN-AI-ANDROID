# RAVEN — Personal Android AI Assistant

RAVEN is a phone-first Android assistant with a blue Siri-inspired voice UI. The business workspace is intentionally not part of the core assistant flow.

## Current capabilities
- Speech recognition with Android SpeechRecognizer
- Spoken replies with Android Text-to-Speech
- Blue animated voice orb
- Supported app launching through Android intents
- Notification Listener foundation (requires explicit user access)
- User-authorized Accessibility Service foundation
- Foreground voice-service foundation
- Command risk/confirmation planning
- STOP / LOCK DOWN handling
- Night Shift foundation

## Build in GitHub Actions
The included workflow installs Gradle 8.9 and builds `app-debug.apk` automatically. Push the project to GitHub, then open Actions → Build RAVEN Android APK.

## Android permissions
RAVEN requests microphone access for voice commands. Notification access and Accessibility access are special Android settings that the user must explicitly enable.

## Important limitation
A true system-level “Hey RAVEN” wake word and full Siri/JARVIS-style device control require Android-supported assistant/default-app roles and a dedicated wake-word/foreground voice implementation. RAVEN must never bypass authentication, passwords, OTPs, or protected screens.
