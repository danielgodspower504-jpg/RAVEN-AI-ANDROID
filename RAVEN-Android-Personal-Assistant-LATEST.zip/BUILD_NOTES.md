# RAVEN Build Notes

The included GitHub Actions workflow builds a debug APK on GitHub after the project is pushed to the repository. It requires a Gradle wrapper (`gradlew`) for the workflow. If Android Studio is used locally, opening the project will regenerate/use the wrapper.

Production voice still requires a wake-word engine and Android assistant-role integration. Android permissions remain user-controlled.
