package com.raven.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri

class RavenCommandEngine(private val context: Context) {
    data class Result(val speech: String, val requiresConfirmation: Boolean = false, val action: (() -> Unit)? = null)

    fun plan(raw: String): Result {
        val q = raw.trim()
        val c = q.lowercase()
        return when {
            c == "stop" || c.contains("lock down") || c.contains("stop all automation") -> Result("All autonomous actions are stopped.")
            c.contains("open whatsapp") -> Result("Opening WhatsApp.") { launchPackage("com.whatsapp", "https://wa.me/") }
            c.contains("open youtube") -> Result("Opening YouTube.") { launchPackage("com.google.android.youtube", "https://youtube.com") }
            c.contains("open chrome") -> Result("Opening Chrome.") { launchPackage("com.android.chrome", "https://google.com") }
            c.contains("call ") -> Result("I can place that call, but I need your confirmation before making it.", true)
            c.contains("send ") && c.contains("message") -> Result("I can prepare that message, but sending it requires your confirmation.", true)
            c.contains("read my notifications") -> Result("I can read notifications after you grant RAVEN Notification Access.")
            c.contains("night shift") -> Result("Night Shift is ready. Only tasks you explicitly approve can run autonomously.")
            else -> Result("I heard: $q. I will check permissions before taking any sensitive action.")
        }
    }

    private fun launchPackage(pkg: String, fallback: String) {
        val launch = context.packageManager.getLaunchIntentForPackage(pkg)
        context.startActivity((launch ?: Intent(Intent.ACTION_VIEW, Uri.parse(fallback))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
