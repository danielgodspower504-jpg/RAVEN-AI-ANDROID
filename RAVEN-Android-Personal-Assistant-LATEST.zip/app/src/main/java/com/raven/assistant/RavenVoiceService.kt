package com.raven.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Foreground-service foundation for hands-free voice. A real wake-word engine must be plugged in here. */
class RavenVoiceService : Service() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("raven_voice", "RAVEN Voice", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, "raven_voice")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("RAVEN is ready")
            .setContentText("Voice assistant is active")
            .setOngoing(true)
            .build()
        startForeground(42, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}
