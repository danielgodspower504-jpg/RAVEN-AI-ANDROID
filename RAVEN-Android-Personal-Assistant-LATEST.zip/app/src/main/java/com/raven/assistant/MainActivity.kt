package com.raven.assistant
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.result.contract.ActivityResultContracts
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*
class MainActivity:ComponentActivity(){
 private lateinit var engine: RavenCommandEngine
 private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (!granted) speak("Microphone permission is required for voice commands.") }
 lateinit var tts:TextToSpeech; var rec:SpeechRecognizer?=null
 override fun onCreate(b:Bundle?){super.onCreate(b); engine=RavenCommandEngine(this); tts=TextToSpeech(this){tts.language=Locale.US}; if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) micPermission.launch(Manifest.permission.RECORD_AUDIO); setContent{RavenUI()}}
 fun speak(s:String){tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"raven")}
 fun listen(done:(String)->Unit){
  rec?.destroy();rec=SpeechRecognizer.createSpeechRecognizer(this).apply{
   setRecognitionListener(object:RecognitionListener{
    override fun onResults(b:Bundle){done(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?:"")}
    override fun onError(e:Int){speak("I didn't catch that. Try again.")}
    override fun onReadyForSpeech(p:Bundle?){};override fun onBeginningOfSpeech(){};override fun onRmsChanged(v:Float){}
    override fun onBufferReceived(b:ByteArray?){};override fun onEndOfSpeech(){};override fun onPartialResults(b:Bundle?){}
    override fun onEvent(t:Int,b:Bundle?){}
   });startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
  }}
 fun command(x:String){ val result=engine.plan(x); speak(result.speech); if(!result.requiresConfirmation) result.action?.invoke() }
 @Composable fun RavenUI(){
  var listening by remember{mutableStateOf(false)};var last by remember{mutableStateOf("Tap the blue RAVEN orb and speak.")};val p by rememberInfiniteTransition(label="p").animateFloat(.94f,1.06f,infiniteRepeatable(tween(1000),RepeatMode.Reverse),label="p")
  MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF2878FF),background=Color(0xFF030711))){
   Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF081B3A),Color(0xFF02050B))))){
    Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){
     Spacer(Modifier.height(35.dp));Text("RAVEN",color=Color(0xFF58A6FF),fontSize=36.sp);Text("YOUR PHONE. YOUR RULES.",color=Color(0xFF8BA7CC),fontSize=12.sp)
     Spacer(Modifier.weight(1f));Text(if(listening)"RAVEN IS LISTENING" else "RAVEN",color=Color(0xFF63A8FF),fontSize=18.sp)
     Spacer(Modifier.height(20.dp));Box(Modifier.size(250.dp).scale(if(listening)p else 1f).background(Color(0xFF1470FF).copy(.12f),CircleShape),contentAlignment=Alignment.Center){
      Box(Modifier.size(190.dp).background(Brush.radialGradient(listOf(Color(0xFF6CC5FF).copy(.9f),Color(0xFF245DFF).copy(.18f),Color.Transparent)),CircleShape),contentAlignment=Alignment.Center){
       Button(onClick={listening=true;last="Listening...";listen{q->listening=false;last=q;command(q)}},modifier=Modifier.size(120.dp),shape=CircleShape){Text("RAVEN")}}}
     Spacer(Modifier.height(28.dp));Text(if(listening)"Speak now..." else last,color=Color.White,fontSize=16.sp)
     Spacer(Modifier.height(20.dp));Button(onClick={speak("I'm RAVEN. I'm ready.")}){Text("TEST VOICE")}
     Spacer(Modifier.weight(1f));Text("VOICE RESPONSES ON • PERSONAL PHONE ASSISTANT",color=Color(0xFF6E86A7),fontSize=11.sp)
    }}}}
