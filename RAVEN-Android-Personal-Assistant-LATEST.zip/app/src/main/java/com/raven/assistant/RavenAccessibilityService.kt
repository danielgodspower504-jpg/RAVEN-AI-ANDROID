package com.raven.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/** User-authorized accessibility bridge. It never bypasses authentication or protected screens. */
class RavenAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Intentionally passive foundation. */ }
    override fun onInterrupt() = Unit
}
