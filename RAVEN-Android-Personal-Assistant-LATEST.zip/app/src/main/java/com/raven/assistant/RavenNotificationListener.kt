package com.raven.assistant
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
class RavenNotificationListener: NotificationListenerService(){
 override fun onNotificationPosted(sbn: StatusBarNotification){ /* user-granted notification access only */ }
}
